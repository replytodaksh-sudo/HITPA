// import apiClient from './apiInterceptor';
// import type { ApiResponse } from './apiInterceptor';
// import type { AxiosRequestConfig } from 'axios';

// /**
//  * Generic API Service
//  * All API calls should go through this service
//  */
// class apiService {
//   /**
//    * GET request
//    */
//   async get<T = any>(
//     endpoint: string,
//     params?: Record<string, any>,
//     config?: AxiosRequestConfig
//   ): Promise<ApiResponse<T>> {
//     const response = await apiClient.get<ApiResponse<T>>(endpoint, {
//       params,
//       ...config,
//     });
//     return response.data;
//   }

//   /**
//    * POST request
//    */
//   async post<T = any>(
//     endpoint: string,
//     data?: any,
//     config?: AxiosRequestConfig
//   ): Promise<ApiResponse<T>> {
//     const response = await apiClient.post<ApiResponse<T>>(endpoint, data, config);
//     return response.data;
//   }

//   /**
//    * PUT request
//    */
//   async put<T = any>(
//     endpoint: string,
//     data?: any,
//     config?: AxiosRequestConfig
//   ): Promise<ApiResponse<T>> {
//     const response = await apiClient.put<ApiResponse<T>>(endpoint, data, config);
//     return response.data;
//   }

//   /**
//    * PATCH request
//    */
//   async patch<T = any>(
//     endpoint: string,
//     data?: any,
//     config?: AxiosRequestConfig
//   ): Promise<ApiResponse<T>> {
//     const response = await apiClient.patch<ApiResponse<T>>(endpoint, data, config);
//     return response.data;
//   }

//   /**
//    * DELETE request
//    */
//   async delete<T = any>(
//     endpoint: string,
//     config?: AxiosRequestConfig
//   ): Promise<ApiResponse<T>> {
//     const response = await apiClient.delete<ApiResponse<T>>(endpoint, config);
//     return response.data;
//   }

//   /**
//    * Upload file (multipart/form-data)
//    */
//   async uploadFile<T = any>(
//     endpoint: string,
//     file: File,
//     additionalData?: Record<string, any>,
//     onUploadProgress?: (progressEvent: any) => void
//   ): Promise<ApiResponse<T>> {
//     const formData = new FormData();
//     formData.append('file', file);

//     // Append additional data if provided
//     if (additionalData) {
//       Object.keys(additionalData).forEach((key) => {
//         formData.append(key, additionalData[key]);
//       });
//     }

//     const response = await apiClient.post<ApiResponse<T>>(endpoint, formData, {
//       headers: {
//         'Content-Type': 'multipart/form-data',
//       },
//       onUploadProgress,
//     });

//     return response.data;
//   }

//   /**
//    * Download file
//    */
//   async downloadFile(
//     endpoint: string,
//     filename: string,
//     params?: Record<string, any>
//   ): Promise<void> {
//     const response = await apiClient.get(endpoint, {
//       params,
//       responseType: 'blob',
//     });

//     // Create blob link to download
//     const url = window.URL.createObjectURL(new Blob([response.data]));
//     const link = document.createElement('a');
//     link.href = url;
//     link.setAttribute('download', filename);
//     document.body.appendChild(link);
//     link.click();
//     link.remove();
//     window.URL.revokeObjectURL(url);
//   }

//   /**
//    * Batch requests (execute multiple requests in parallel)
//    */
//   async batch<T = any>(
//     requests: Array<() => Promise<ApiResponse<any>>>
//   ): Promise<ApiResponse<T>[]> {
//     return Promise.all(requests.map((request) => request()));
//   }
// }

// // Export singleton instance
// export const apiService = new apiService();

// // Export class for testing or custom instances
// export default apiService;



// ============================================================================
// FILE: src/services/apiService.ts (UNIFIED VERSION)
// Combines Keycloak authentication from File B with Axios client from File A
// ============================================================================

import apiClient from './apiInterceptor';
import type { ApiResponse } from './apiInterceptor';
import type { AxiosRequestConfig } from 'axios';
import keycloak from '../keycloak.config';

/**
 * Unified API Service
 * - Uses Axios client with interceptors (from File A)
 * - Integrates Keycloak authentication (from File B)
 * - All API calls should go through this service
 */
class ApiServiceClass {
  /**
   * Ensure Keycloak token is valid before making requests
   * Refreshes token if it expires in less than 30 seconds
   */
  private async ensureValidToken(): Promise<void> {
    try {
      // Refresh token if it expires in less than 30 seconds
      await keycloak.updateToken(30);

      // Update token in sessionStorage for axios interceptor to use
      if (keycloak.token) {
        sessionStorage.setItem('accessToken', keycloak.token);
      }
    } catch (error) {
      console.error('Failed to refresh Keycloak token:', error);
      // Redirect to login if refresh fails
      keycloak.login();
    }
  }

  /**
   * Handle API errors with Keycloak integration
   */
  private handleError(error: any): never {
    if (error.response?.status === 401) {
      // Unauthorized - use Keycloak login
      keycloak.login();
    }
    throw error;
  }

  /**
   * GET request
   */
  async get<T = any>(
    endpoint: string,
    params?: Record<string, any>,
    config?: AxiosRequestConfig
  ): Promise<ApiResponse<T>> {
    await this.ensureValidToken();

    try {
      const response = await apiClient.get<ApiResponse<T>>(endpoint, {
        params,
        ...config,
      });
      return response.data;
    } catch (error) {
      return this.handleError(error);
    }
  }

  /**
   * POST request
   */
  async post<T = any>(
    endpoint: string,
    data?: any,
    config?: AxiosRequestConfig
  ): Promise<ApiResponse<T>> {
    await this.ensureValidToken();

    try {
      const response = await apiClient.post<ApiResponse<T>>(endpoint, data, config);
      return response.data;
    } catch (error) {
      return this.handleError(error);
    }
  }

  /**
   * PUT request
   */
  async put<T = any>(
    endpoint: string,
    data?: any,
    config?: AxiosRequestConfig
  ): Promise<ApiResponse<T>> {
    await this.ensureValidToken();

    try {
      const response = await apiClient.put<ApiResponse<T>>(endpoint, data, config);
      return response.data;
    } catch (error) {
      return this.handleError(error);
    }
  }

  /**
   * PATCH request
   */
  async patch<T = any>(
    endpoint: string,
    data?: any,
    config?: AxiosRequestConfig
  ): Promise<ApiResponse<T>> {
    await this.ensureValidToken();

    try {
      const response = await apiClient.patch<ApiResponse<T>>(endpoint, data, config);
      return response.data;
    } catch (error) {
      return this.handleError(error);
    }
  }

  /**
   * DELETE request
   */
  async delete<T = any>(
    endpoint: string,
    config?: AxiosRequestConfig
  ): Promise<ApiResponse<T>> {
    await this.ensureValidToken();

    try {
      const response = await apiClient.delete<ApiResponse<T>>(endpoint, config);
      return response.data;
    } catch (error) {
      return this.handleError(error);
    }
  }

  /**
   * Upload single file (multipart/form-data)
   */
  async uploadFile<T = any>(
    endpoint: string,
    file: File,
    additionalData?: Record<string, any>,
    onUploadProgress?: (progressEvent: any) => void
  ): Promise<ApiResponse<T>> {
    await this.ensureValidToken();

    try {
      const formData = new FormData();
      formData.append('file', file);

      // Append additional data if provided
      if (additionalData) {
        Object.keys(additionalData).forEach((key) => {
          formData.append(key, additionalData[key]);
        });
      }

      const response = await apiClient.post<ApiResponse<T>>(endpoint, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
        onUploadProgress,
      });

      return response.data;
    } catch (error) {
      return this.handleError(error);
    }
  }

  /**
   * Upload multiple files (multipart/form-data)
   */
  async uploadFiles<T = any>(
    endpoint: string,
    files: File[],
    additionalData?: Record<string, any>,
    onUploadProgress?: (progressEvent: any) => void
  ): Promise<ApiResponse<T>> {
    await this.ensureValidToken();

    try {
      const formData = new FormData();

      // Append all files
      files.forEach((file, index) => {
        formData.append(`file${index}`, file);
      });

      // Append additional data if provided
      if (additionalData) {
        Object.keys(additionalData).forEach((key) => {
          formData.append(key, additionalData[key]);
        });
      }

      const response = await apiClient.post<ApiResponse<T>>(endpoint, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
        onUploadProgress,
      });

      return response.data;
    } catch (error) {
      return this.handleError(error);
    }
  }

  /**
   * Download file
   */
  async downloadFile(
    endpoint: string,
    filename: string,
    params?: Record<string, any>
  ): Promise<void> {
    await this.ensureValidToken();

    try {
      const response = await apiClient.get(endpoint, {
        params,
        responseType: 'blob',
      });

      // Create blob link to download
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', filename);
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(url);
    } catch (error) {
      this.handleError(error);
    }
  }

  /**
   * Batch requests (execute multiple requests in parallel)
   */
  async batch<T = any>(
    requests: Array<() => Promise<ApiResponse<any>>>
  ): Promise<ApiResponse<T>[]> {
    return Promise.all(requests.map((request) => request()));
  }

  /**
   * GET request with raw Axios response (useful for custom handling)
   */
  async getRaw(
    endpoint: string,
    params?: Record<string, any>,
    config?: AxiosRequestConfig
  ): Promise<any> {
    await this.ensureValidToken();

    try {
      return await apiClient.get(endpoint, {
        params,
        ...config,
      });
    } catch (error) {
      return this.handleError(error);
    }
  }

  /**
   * POST request with raw Axios response
   */
  async postRaw(
    endpoint: string,
    data?: any,
    config?: AxiosRequestConfig
  ): Promise<any> {
    await this.ensureValidToken();

    try {
      return await apiClient.post(endpoint, data, config);
    } catch (error) {
      return this.handleError(error);
    }
  }
}

// Export singleton instance (lowercase for backward compatibility)
export const apiService = new ApiServiceClass();

// Export class (uppercase for new code)
export const ApiService = ApiServiceClass;

// Default export
export default apiService;